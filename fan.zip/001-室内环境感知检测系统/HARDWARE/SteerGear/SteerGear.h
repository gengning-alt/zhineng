#ifndef __STEERGEAR_H
#define __STEERGEAR_H


void SteerGear_PWM(uint16_t duty);
void TIM2_PWM_Init(uint16_t arr,uint16_t psc);

#endif
