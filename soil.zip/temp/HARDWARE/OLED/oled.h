#ifndef __OLED_H_
#define __OLED_H_

#include "stm32f10x.h"

#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����    

#define OLED_DC_Clr()	GPIO_WriteBit(GPIOE,GPIO_Pin_1,Bit_RESET)//DC
#define OLED_DC_Set()	GPIO_WriteBit(GPIOE,GPIO_Pin_1,Bit_SET)

#define OLED_RST_Clr()	GPIO_WriteBit(GPIOE,GPIO_Pin_2,Bit_RESET)//RES
#define OLED_RST_Set()	GPIO_WriteBit(GPIOE,GPIO_Pin_2,Bit_SET)

#define OLED_SCLK_Clr()	GPIO_WriteBit(GPIOB,GPIO_Pin_9,Bit_RESET)//SCLK
#define OLED_SCLK_Set()	GPIO_WriteBit(GPIOB,GPIO_Pin_9,Bit_SET)

#define OLED_SDIN_Clr()	GPIO_WriteBit(GPIOB,GPIO_Pin_8,Bit_RESET)//SDIN
#define OLED_SDIN_Set()	GPIO_WriteBit(GPIOB,GPIO_Pin_8,Bit_SET)

#define OLED_CS_Clr()	GPIO_WriteBit(GPIOE,GPIO_Pin_3,Bit_RESET)//CS
#define OLED_CS_Set()	GPIO_WriteBit(GPIOE,GPIO_Pin_3,Bit_SET)

//OLED�����ú���
void OLED_Hardware_Init(void);
void OLED_WR_Byte(uint8_t dat,uint8_t cmd);	    
void OLED_Display_On(void);
void OLED_Display_Off(void);	   							   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_Draw(uint8_t byte);

void OLED_ShowChar(uint16_t x,uint16_t y, uint8_t num, uint8_t size);
void OLED_ShowString(uint16_t x,uint16_t y,char *p, uint8_t size);
void OLED_ShowInt32Num(uint16_t x,uint16_t y, int32_t num, uint8_t len, uint8_t size);
void OLED_DrawFont16(uint16_t x, uint16_t y, char *s);
void OLED_DrawFont32(uint16_t x, uint16_t y, char *s);
void OLED_Show_Str(uint16_t x, uint16_t y, char *str,uint8_t size);
void OLED_ShowNum(uint8_t x,uint8_t y,uint16_t num,u8 len,uint8_t size);

#endif

