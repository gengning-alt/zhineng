#ifndef __DELAY_H_
#define __DELAY_H_
#include "stm32f10x.h"

void Delay_Init(void);
void Delay_us(uint16_t ctr);
void Delay_ms(uint16_t ctr);

#endif
